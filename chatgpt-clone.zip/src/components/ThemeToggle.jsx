function ThemeToggle({ toggle }) {
  return (
    <button className="theme-toggle" onClick={toggle}>
      Toggle Theme
    </button>
  );
}

export default ThemeToggle;
