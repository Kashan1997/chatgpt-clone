import React from "react";
import Message from "./Message";

function ChatWindow({ messages, loading }) {
  return (
    <div className="chat-window">
      {messages.map((msg, i) => (
        <Message key={i} message={msg} />
      ))}
      {loading && <p className="typing">Assistant is typing...</p>}
    </div>
  );
}

export default ChatWindow;
