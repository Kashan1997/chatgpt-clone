import React, { useState } from "react";
import axios from "axios";
import ChatWindow from "./components/ChatWindow";
import InputBox from "./components/InputBox";
import ThemeToggle from "./components/ThemeToggle";
import "./styles.css";

function App() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  const sendMessage = async (userInput) => {
    const newMessages = [...messages, { role: "user", content: userInput }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-4",
          messages: newMessages,
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.REACT_APP_OPENAI_API_KEY}`,
          },
        }
      );
      setMessages([...newMessages, response.data.choices[0].message]);
    } catch (err) {
      alert("Error: " + err.message);
    }

    setLoading(false);
  };

  return (
    <div className={darkMode ? "app dark" : "app"}>
      <ThemeToggle toggle={() => setDarkMode(!darkMode)} />
      <ChatWindow messages={messages} loading={loading} />
      <InputBox onSend={sendMessage} />
    </div>
  );
}

export default App;
