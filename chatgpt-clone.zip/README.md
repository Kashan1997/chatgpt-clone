# ChatGPT Clone

A simple React-based ChatGPT clone using OpenAI API.